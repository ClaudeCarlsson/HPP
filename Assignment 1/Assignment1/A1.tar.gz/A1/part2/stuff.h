#define G 78

void print_pyramid(int pyramidSize);
